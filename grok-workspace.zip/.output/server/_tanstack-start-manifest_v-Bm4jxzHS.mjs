//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bm4jxzHS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/book",
			"/contacts",
			"/services",
			"/vip"
		],
		preloads: ["/assets/index-DX53EU25.js", "/assets/shop-BH1UVWY7.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DX53EU25.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-8rVI0ivR.js",
			"/assets/app-shell-CjkoNw6S.js",
			"/assets/clock-3-DCNCnkYN.js",
			"/assets/install-card-lQlnHgb8.js"
		]
	},
	"/book": {
		filePath: "/workspace/src/routes/book.tsx",
		children: void 0,
		preloads: [
			"/assets/book-D34zKFcC.js",
			"/assets/app-shell-CjkoNw6S.js",
			"/assets/message-circle-Brt_ePHP.js",
			"/assets/textarea-BFMJLtbN.js"
		]
	},
	"/contacts": {
		filePath: "/workspace/src/routes/contacts.tsx",
		children: void 0,
		preloads: [
			"/assets/contacts-Dxb4JHcU.js",
			"/assets/app-shell-CjkoNw6S.js",
			"/assets/clock-3-DCNCnkYN.js",
			"/assets/install-card-lQlnHgb8.js",
			"/assets/message-circle-Brt_ePHP.js"
		]
	},
	"/services": {
		filePath: "/workspace/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-CkYfZ8c9.js",
			"/assets/app-shell-CjkoNw6S.js",
			"/assets/clock-3-DCNCnkYN.js"
		]
	},
	"/vip": {
		filePath: "/workspace/src/routes/vip.tsx",
		children: void 0,
		preloads: [
			"/assets/vip-Dkfl5mvn.js",
			"/assets/app-shell-CjkoNw6S.js",
			"/assets/message-circle-Brt_ePHP.js",
			"/assets/textarea-BFMJLtbN.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
