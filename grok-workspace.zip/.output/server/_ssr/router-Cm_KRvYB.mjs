import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useRouter, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, m as useRouterState, p as HeadContent, v as lazyRouteComponent, w as require_jsx_runtime, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Cm_KRvYB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: (error instanceof Error ? error.message : "Не удалось открыть страницу.") || "Не удалось открыть страницу."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var SHOP = {
	name: "Мобион",
	tagline: "Ремонт телефонов",
	city: "Владикавказ",
	address: "ул. Иристонская, 29",
	addressFull: "Владикавказ, ул. Иристонская, 29",
	phoneDisplay: "8 (999) 999-91-15",
	phoneTel: "+79999999115",
	whatsapp: "79999999115",
	mapsUrl: "https://yandex.ru/maps/33/vladikavkaz/house/iristonskaya_ulitsa_29/YE0YcAFkTkMBQFppfXx3c3xkYA==/",
	mapsQuery: "https://yandex.ru/maps/?text=Владикавказ%2C%20Иристонская%20улица%2C%2029",
	hoursWeek: "10:00–20:00",
	hoursSunday: "11:00–18:00",
	timezone: "Europe/Moscow",
	warranty: "90 дней",
	telegramBot: "vip_mobion_bot",
	telegramUrl: "https://t.me/vip_mobion_bot"
};
var DEVICES = [
	"iPhone",
	"Samsung",
	"Xiaomi",
	"Redmi",
	"Honor",
	"Huawei",
	"Realme",
	"Pixel",
	"Другое"
];
var ISSUE_OPTIONS = [
	"Экран / стекло",
	"Батарея",
	"Не заряжается",
	"После воды",
	"Камера",
	"Кнопки",
	"Динамик / микрофон",
	"Прошивка / зависает",
	"Другое"
];
var CATEGORIES = [
	{
		id: "all",
		label: "Все"
	},
	{
		id: "screen",
		label: "Экраны"
	},
	{
		id: "power",
		label: "Питание"
	},
	{
		id: "board",
		label: "Плата"
	},
	{
		id: "parts",
		label: "Детали"
	},
	{
		id: "soft",
		label: "Софт"
	}
];
var SERVICES = [
	{
		id: "screen-iphone",
		category: "screen",
		title: "Экран iPhone",
		priceFrom: 4500,
		time: "40–90 мин",
		image: "/images/screen.jpg",
		desc: "Качественные матрицы. Сохраняем Face ID, где это возможно."
	},
	{
		id: "screen-android",
		category: "screen",
		title: "Экран Android",
		priceFrom: 2500,
		time: "40–70 мин",
		image: "/images/screen.jpg",
		desc: "Samsung, Xiaomi, Honor, Realme и другие популярные модели."
	},
	{
		id: "glass-cam",
		category: "screen",
		title: "Стекло камеры",
		priceFrom: 900,
		time: "20 мин",
		desc: "Меняем только стекло — модуль камеры не трогаем."
	},
	{
		id: "battery",
		category: "power",
		title: "Замена батареи",
		priceFrom: 1500,
		time: "30–50 мин",
		image: "/images/battery.jpg",
		desc: "Новые аккумуляторы с проверкой циклов и ёмкости."
	},
	{
		id: "charge",
		category: "power",
		title: "Разъём зарядки",
		priceFrom: 1800,
		time: "40–70 мин",
		image: "/images/charging.jpg",
		desc: "Грязь, люфт, искрение, «не видит кабель» — чиним на месте."
	},
	{
		id: "water",
		category: "board",
		title: "После воды",
		priceFrom: 2500,
		time: "1–3 дня",
		image: "/images/water.jpg",
		desc: "Разбор, промывка платы, сушка. Чем раньше принесёте — тем выше шанс."
	},
	{
		id: "board",
		category: "board",
		title: "Ремонт платы",
		priceFrom: 3500,
		time: "1–5 дней",
		desc: "Не включается, короткое замыкание, слетевшие линии питания."
	},
	{
		id: "camera",
		category: "parts",
		title: "Камера",
		priceFrom: 2e3,
		time: "40–80 мин",
		desc: "Чёрный экран, пятна, не фокусирует, выпадает модуль."
	},
	{
		id: "speaker",
		category: "parts",
		title: "Динамик и микрофон",
		priceFrom: 1400,
		time: "30–60 мин",
		desc: "Тихий звук, хрип, собеседник вас не слышит."
	},
	{
		id: "buttons",
		category: "parts",
		title: "Кнопки",
		priceFrom: 1200,
		time: "30–50 мин",
		desc: "Питание, громкость, переключатель беззвучного режима."
	},
	{
		id: "firmware",
		category: "soft",
		title: "Прошивка",
		priceFrom: 800,
		time: "20–40 мин",
		desc: "Зависает, логотип, сброс, обновление без потери данных — если возможно."
	},
	{
		id: "unlock",
		category: "soft",
		title: "Разблокировка",
		priceFrom: 800,
		time: "15–40 мин",
		desc: "Графический ключ, Google-аккаунт, забытый пароль — по ситуации."
	},
	{
		id: "diag",
		category: "soft",
		title: "Диагностика",
		priceFrom: 0,
		time: "15 мин",
		desc: "Смотрим, называем цену до работы. Если не чините — ничего не берём."
	}
];
var STEPS = [
	{
		n: "01",
		title: "Заявка или звонок",
		text: "Опишите модель и что случилось — ответим в течение нескольких минут."
	},
	{
		n: "02",
		title: "Диагностика",
		text: "15 минут на столе. Честная цена до того, как разберём дальше."
	},
	{
		n: "03",
		title: "Ремонт",
		text: "Большинство экранов и батарей — в тот же день, часто за час."
	},
	{
		n: "04",
		title: "Гарантия",
		text: "90 дней на работу и запчасть. Чек и рекомендации, как беречь."
	}
];
var BRANDS = [
	"iPhone",
	"Samsung",
	"Xiaomi",
	"Honor",
	"Huawei",
	"Realme",
	"Pixel",
	"OnePlus"
];
function formatPrice(n) {
	if (n === 0) return "Бесплатно";
	return `от ${n.toLocaleString("ru-RU")} ₽`;
}
function getShopStatus(now = /* @__PURE__ */ new Date()) {
	const parts = Object.fromEntries(new Intl.DateTimeFormat("en-GB", {
		timeZone: SHOP.timezone,
		weekday: "short",
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	}).formatToParts(now).map((p) => [p.type, p.value]));
	const weekday = parts.weekday ?? "";
	const hour = Number(parts.hour);
	const minute = Number(parts.minute);
	const mins = hour * 60 + minute;
	const isSunday = weekday === "Sun";
	const open = mins >= (isSunday ? 660 : 600) && mins < (isSunday ? 1080 : 1200);
	return {
		open,
		todayLabel: isSunday ? SHOP.hoursSunday : SHOP.hoursWeek,
		statusLabel: open ? "Открыто" : "Закрыто"
	};
}
function callHref() {
	return `tel:${SHOP.phoneTel}`;
}
function whatsappHref(text) {
	const base = `https://wa.me/${SHOP.whatsapp}`;
	if (!text) return base;
	return `${base}?text=${encodeURIComponent(text)}`;
}
var START_ROUTES = {
	services: "/services",
	uslugi: "/services",
	price: "/services",
	prices: "/services",
	prais: "/services",
	book: "/book",
	zayavka: "/book",
	zapis: "/book",
	repair: "/book",
	contacts: "/contacts",
	contact: "/contacts",
	adres: "/contacts",
	vip: "/vip",
	club: "/vip",
	menu: "/vip",
	rules: "/vip?view=rules",
	pravila: "/vip?view=rules",
	about: "/vip?view=about",
	vozmozhnosti: "/vip?view=about",
	subscribe: "/vip?view=pay",
	podpiska: "/vip?view=pay",
	oplata: "/vip?view=pay",
	pay: "/vip?view=pay",
	status: "/vip?view=status",
	moya: "/vip?view=status",
	chat: "/vip?view=chats",
	chats: "/vip?view=chats",
	flud: "/vip?view=chats"
};
function getWebApp() {
	if (typeof window === "undefined") return null;
	return window.Telegram?.WebApp ?? null;
}
function isTelegram() {
	const wa = getWebApp();
	if (!wa) return false;
	return Boolean(wa.initData) || wa.platform !== "unknown" && wa.platform !== "";
}
function telegramUser() {
	return getWebApp()?.initDataUnsafe.user ?? null;
}
function readStartParam() {
	if (typeof window === "undefined") return "";
	const params = new URLSearchParams(window.location.search);
	const fromQuery = params.get("tgWebAppStartParam") || params.get("startapp") || "";
	return ((getWebApp()?.initDataUnsafe.start_param ?? "") || fromQuery).toLowerCase().trim();
}
function openExternal(url) {
	const tg = getWebApp();
	if (tg && isTelegram()) {
		tg.openLink(url);
		return;
	}
	window.open(url, "_blank", "noopener,noreferrer");
}
function openTelegram(url) {
	const tg = getWebApp();
	if (tg && isTelegram() && tg.openTelegramLink) {
		tg.openTelegramLink(url);
		return;
	}
	window.open(url, "_blank", "noopener,noreferrer");
}
function haptic(kind = "light") {
	const h = getWebApp()?.HapticFeedback;
	if (!h) return;
	if (kind === "success" || kind === "error") h.notificationOccurred(kind);
	else h.impactOccurred("light");
}
function TelegramBridge() {
	const router = useRouter();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		const tg = getWebApp();
		if (!tg) return;
		tg.ready();
		tg.expand();
		tg.setHeaderColor("#0c0d10");
		tg.setBackgroundColor("#0c0d10");
		tg.disableVerticalSwipes?.();
		const inTg = isTelegram();
		document.documentElement.classList.toggle("in-telegram", inTg);
		if (!inTg) return;
		const start = readStartParam();
		if (start === "call" || start === "zvonok") {
			window.location.href = callHref();
			return;
		}
		const target = START_ROUTES[start];
		if (target && router.state.location.pathname === "/") router.history.push(target);
	}, [router]);
	(0, import_react.useEffect)(() => {
		const tg = getWebApp();
		if (!tg || !isTelegram()) return;
		const onBack = () => {
			if (window.history.length > 1) router.history.back();
			else router.navigate({ to: "/" });
		};
		if (pathname === "/") tg.BackButton.hide();
		else {
			tg.BackButton.show();
			tg.BackButton.onClick(onBack);
		}
		return () => {
			tg.BackButton.offClick(onBack);
			tg.BackButton.hide();
		};
	}, [pathname, router]);
	return null;
}
var styles_default = "/assets/styles-BBB89_PF.css";
var APP_NAME = "Мобион";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c0d10"
			},
			{
				name: "description",
				content: "Мобион — ремонт телефонов во Владикавказе. ул. Иристонская, 29. Диагностика бесплатно."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Unbounded:wght@500;600&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { src: "https://telegram.org/js/telegram-web-app.js" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$4 = () => import("./routes-C-633Hx6.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./book-CDMnm1rJ.mjs");
var Route$3 = createFileRoute("/book")({
	validateSearch: (search) => ({ issue: typeof search.issue === "string" ? search.issue : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./contacts-sGcgHIKz.mjs");
var Route$2 = createFileRoute("/contacts")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./services-CutJ_mwU.mjs");
var Route$1 = createFileRoute("/services")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var VIP_VIEWS = [
	"menu",
	"rules",
	"about",
	"pay",
	"status",
	"chats"
];
var FLUD_URL = "https://t.me/mobionflud";
var VIP_RULES = [
	"Общайтесь вежливо. Оскорбления и унижения — повод для бана.",
	"Чат про ремонт телефонов. Далеко от темы не уходите.",
	"Без оскорбительного, неприемлемого и вредоносного контента.",
	"Без мата и призывов нарушать правила Telegram.",
	"Не спамьте: повторы и реклама без спроса мешают разбору.",
	"Чужие схемы, фото плат и уроки — только с разрешения автора.",
	"Модератор удаляет сообщения и блокирует за нарушение.",
	"VIP-чат открыт только по оплаченной подписке через бота."
];
var VIP_FEATURES = [
	{
		title: "Обучение мастеров",
		text: "Закрытый разбор ремонта телефонов: платы, типовые поломки, как не убить устройство на столе."
	},
	{
		title: "VIP-чат",
		text: "Доступ только по платной подписке. Ссылку на вход присылает бот после оплаты."
	},
	{
		title: "Курилка",
		text: "Отдельный чат для неформального общения мастеров — со своими правилами."
	},
	{
		title: "Заявка из приложения",
		text: "Подписку, правила и чаты можно открыть прямо здесь, не листая сообщения бота."
	}
];
var KEY = "mobion.vip.request";
function loadVipRequest() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed.name !== "string") return null;
		return parsed;
	} catch {
		return null;
	}
}
function saveVipRequest(input) {
	const request = {
		...input,
		id: crypto.randomUUID(),
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	localStorage.setItem(KEY, JSON.stringify(request));
	return request;
}
function vipMessage(r) {
	const lines = ["Хочу доступ в VIP-чат Mobion.", `Имя: ${r.name}`];
	if (r.username.trim()) lines.push(`Telegram: @${r.username.replace(/^@/, "")}`);
	if (r.phone.trim()) lines.push(`Телефон: ${r.phone.trim()}`);
	if (r.comment.trim()) lines.push(`Комментарий: ${r.comment.trim()}`);
	return lines.join("\n");
}
var $$splitComponentImporter = () => import("./vip-CzoCFOeu.mjs");
var Route = createFileRoute("/vip")({
	validateSearch: (search) => {
		const raw = typeof search.view === "string" ? search.view : "menu";
		return { view: VIP_VIEWS.includes(raw) ? raw : "menu" };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	BookRoute: Route$3.update({
		id: "/book",
		path: "/book",
		getParentRoute: () => Route$5
	}),
	ContactsRoute: Route$2.update({
		id: "/contacts",
		path: "/contacts",
		getParentRoute: () => Route$5
	}),
	ServicesRoute: Route$1.update({
		id: "/services",
		path: "/services",
		getParentRoute: () => Route$5
	}),
	VipRoute: Route.update({
		id: "/vip",
		path: "/vip",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { getShopStatus as C, formatPrice as S, ISSUE_OPTIONS as _, VIP_RULES as a, STEPS as b, vipMessage as c, openExternal as d, openTelegram as f, DEVICES as g, CATEGORIES as h, VIP_FEATURES as i, Route$3 as l, BRANDS as m, Route as n, loadVipRequest as o, telegramUser as p, FLUD_URL as r, saveVipRequest as s, router_exports as t, haptic as u, SERVICES as v, whatsappHref as w, callHref as x, SHOP as y };
