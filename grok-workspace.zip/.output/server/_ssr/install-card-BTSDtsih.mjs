import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Share, p as Download } from "../_libs/lucide-react.mjs";
import { n as Button } from "./app-shell-Cd6PMgWg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/install-card-BTSDtsih.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useInstallState() {
	const [promptEvent, setPromptEvent] = (0, import_react.useState)(null);
	const [standalone, setStandalone] = (0, import_react.useState)(false);
	const [ios, setIos] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const nav = window.navigator;
		const isStandalone = window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
		setStandalone(isStandalone);
		setIos(/iphone|ipad|ipod/i.test(window.navigator.userAgent));
		const onPrompt = (event) => {
			event.preventDefault();
			setPromptEvent(event);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		return () => window.removeEventListener("beforeinstallprompt", onPrompt);
	}, []);
	async function install() {
		if (!promptEvent) return;
		await promptEvent.prompt();
		await promptEvent.userChoice;
		setPromptEvent(null);
	}
	return {
		promptEvent,
		standalone,
		ios,
		install
	};
}
function InstallCard() {
	const { promptEvent, standalone, ios, install } = useInstallState();
	if (standalone) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-base font-medium tracking-tight",
				children: "На рабочий стол"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: "Установите Мобион как приложение — иконка на телефоне, быстрый звонок и заявка без браузера."
			}),
			promptEvent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-4 w-full",
				size: "lg",
				onClick: () => void install(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
					className: "size-4",
					strokeWidth: 2
				}), "Установить на телефон"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 rounded-md bg-surface-2 px-3.5 py-3 text-sm leading-relaxed text-muted",
				children: ios ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"На iPhone: кнопка «Поделиться»",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share, {
						className: "mx-1 inline size-3.5 align-text-bottom",
						strokeWidth: 2
					}),
					"→ «На экран Домой»."
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "В Chrome: меню → «Установить приложение» или «На экран». Иконка появится рядом с остальными." })
			})
		]
	});
}
//#endregion
export { InstallCard as t };
