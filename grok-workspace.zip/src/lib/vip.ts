export type VipView = "menu" | "rules" | "about" | "pay" | "status" | "chats";

export const VIP_VIEWS: VipView[] = ["menu", "rules", "about", "pay", "status", "chats"];

export const FLUD_URL = "https://t.me/mobionflud";
export const FLUD_RULES_URL =
  "https://telegra.ph/Pravila-dlya-fludilki--Mobion-Chat-dlya-masterov-06-03";

export const VIP_RULES = [
  "Общайтесь вежливо. Оскорбления и унижения — повод для бана.",
  "Чат про ремонт телефонов. Далеко от темы не уходите.",
  "Без оскорбительного, неприемлемого и вредоносного контента.",
  "Без мата и призывов нарушать правила Telegram.",
  "Не спамьте: повторы и реклама без спроса мешают разбору.",
  "Чужие схемы, фото плат и уроки — только с разрешения автора.",
  "Модератор удаляет сообщения и блокирует за нарушение.",
  "VIP-чат открыт только по оплаченной подписке через бота.",
] as const;

export const VIP_FEATURES = [
  {
    title: "Обучение мастеров",
    text: "Закрытый разбор ремонта телефонов: платы, типовые поломки, как не убить устройство на столе.",
  },
  {
    title: "VIP-чат",
    text: "Доступ только по платной подписке. Ссылку на вход присылает бот после оплаты.",
  },
  {
    title: "Курилка",
    text: "Отдельный чат для неформального общения мастеров — со своими правилами.",
  },
  {
    title: "Заявка из приложения",
    text: "Подписку, правила и чаты можно открыть прямо здесь, не листая сообщения бота.",
  },
] as const;

export type VipRequest = {
  id: string;
  name: string;
  phone: string;
  username: string;
  comment: string;
  createdAt: string;
};

const KEY = "mobion.vip.request";

export function loadVipRequest(): VipRequest | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as VipRequest;
    if (!parsed || typeof parsed.name !== "string") return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveVipRequest(input: Omit<VipRequest, "id" | "createdAt">): VipRequest {
  const request: VipRequest = {
    ...input,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  };
  localStorage.setItem(KEY, JSON.stringify(request));
  return request;
}

export function vipMessage(r: Pick<VipRequest, "name" | "phone" | "username" | "comment">) {
  const lines = [
    "Хочу доступ в VIP-чат Mobion.",
    `Имя: ${r.name}`,
  ];
  if (r.username.trim()) lines.push(`Telegram: @${r.username.replace(/^@/, "")}`);
  if (r.phone.trim()) lines.push(`Телефон: ${r.phone.trim()}`);
  if (r.comment.trim()) lines.push(`Комментарий: ${r.comment.trim()}`);
  return lines.join("\n");
}
