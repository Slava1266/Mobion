export type Booking = {
  id: string;
  name: string;
  phone: string;
  device: string;
  issue: string;
  comment: string;
  createdAt: string;
};

const KEY = "mobion.bookings";

export function loadBookings(): Booking[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Booking[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveBooking(input: Omit<Booking, "id" | "createdAt">): Booking {
  const booking: Booking = {
    ...input,
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
  };
  const next = [booking, ...loadBookings()].slice(0, 20);
  localStorage.setItem(KEY, JSON.stringify(next));
  return booking;
}

export function bookingMessage(b: Pick<Booking, "name" | "phone" | "device" | "issue" | "comment">) {
  const lines = [
    "Здравствуйте! Хочу записаться на ремонт в Мобион.",
    `Имя: ${b.name}`,
    `Телефон: ${b.phone}`,
    `Устройство: ${b.device}`,
    `Проблема: ${b.issue}`,
  ];
  if (b.comment.trim()) lines.push(`Комментарий: ${b.comment.trim()}`);
  return lines.join("\n");
}
