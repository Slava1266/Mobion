export const SHOP = {
  name: "Мобион",
  tagline: "Ремонт телефонов",
  city: "Владикавказ",
  address: "ул. Иристонская, 29",
  addressFull: "Владикавказ, ул. Иристонская, 29",
  phoneDisplay: "8 (999) 999-91-15",
  phoneTel: "+79999999115",
  whatsapp: "79999999115",
  mapsUrl:
    "https://yandex.ru/maps/33/vladikavkaz/house/iristonskaya_ulitsa_29/YE0YcAFkTkMBQFppfXx3c3xkYA==/",
  mapsQuery: "https://yandex.ru/maps/?text=Владикавказ%2C%20Иристонская%20улица%2C%2029",
  hoursWeek: "10:00–20:00",
  hoursSunday: "11:00–18:00",
  timezone: "Europe/Moscow",
  warranty: "90 дней",
  telegramBot: "vip_mobion_bot",
  telegramUrl: "https://t.me/vip_mobion_bot",
} as const;

export const DEVICES = [
  "iPhone",
  "Samsung",
  "Xiaomi",
  "Redmi",
  "Honor",
  "Huawei",
  "Realme",
  "Pixel",
  "Другое",
] as const;

export const ISSUE_OPTIONS = [
  "Экран / стекло",
  "Батарея",
  "Не заряжается",
  "После воды",
  "Камера",
  "Кнопки",
  "Динамик / микрофон",
  "Прошивка / зависает",
  "Другое",
] as const;

export type ServiceCategory = "screen" | "power" | "board" | "parts" | "soft";

export const CATEGORIES: { id: ServiceCategory | "all"; label: string }[] = [
  { id: "all", label: "Все" },
  { id: "screen", label: "Экраны" },
  { id: "power", label: "Питание" },
  { id: "board", label: "Плата" },
  { id: "parts", label: "Детали" },
  { id: "soft", label: "Софт" },
];

export type Service = {
  id: string;
  category: ServiceCategory;
  title: string;
  priceFrom: number;
  time: string;
  image?: string;
  desc: string;
};

export const SERVICES: Service[] = [
  {
    id: "screen-iphone",
    category: "screen",
    title: "Экран iPhone",
    priceFrom: 4500,
    time: "40–90 мин",
    image: "/images/screen.jpg",
    desc: "Качественные матрицы. Сохраняем Face ID, где это возможно.",
  },
  {
    id: "screen-android",
    category: "screen",
    title: "Экран Android",
    priceFrom: 2500,
    time: "40–70 мин",
    image: "/images/screen.jpg",
    desc: "Samsung, Xiaomi, Honor, Realme и другие популярные модели.",
  },
  {
    id: "glass-cam",
    category: "screen",
    title: "Стекло камеры",
    priceFrom: 900,
    time: "20 мин",
    desc: "Меняем только стекло — модуль камеры не трогаем.",
  },
  {
    id: "battery",
    category: "power",
    title: "Замена батареи",
    priceFrom: 1500,
    time: "30–50 мин",
    image: "/images/battery.jpg",
    desc: "Новые аккумуляторы с проверкой циклов и ёмкости.",
  },
  {
    id: "charge",
    category: "power",
    title: "Разъём зарядки",
    priceFrom: 1800,
    time: "40–70 мин",
    image: "/images/charging.jpg",
    desc: "Грязь, люфт, искрение, «не видит кабель» — чиним на месте.",
  },
  {
    id: "water",
    category: "board",
    title: "После воды",
    priceFrom: 2500,
    time: "1–3 дня",
    image: "/images/water.jpg",
    desc: "Разбор, промывка платы, сушка. Чем раньше принесёте — тем выше шанс.",
  },
  {
    id: "board",
    category: "board",
    title: "Ремонт платы",
    priceFrom: 3500,
    time: "1–5 дней",
    desc: "Не включается, короткое замыкание, слетевшие линии питания.",
  },
  {
    id: "camera",
    category: "parts",
    title: "Камера",
    priceFrom: 2000,
    time: "40–80 мин",
    desc: "Чёрный экран, пятна, не фокусирует, выпадает модуль.",
  },
  {
    id: "speaker",
    category: "parts",
    title: "Динамик и микрофон",
    priceFrom: 1400,
    time: "30–60 мин",
    desc: "Тихий звук, хрип, собеседник вас не слышит.",
  },
  {
    id: "buttons",
    category: "parts",
    title: "Кнопки",
    priceFrom: 1200,
    time: "30–50 мин",
    desc: "Питание, громкость, переключатель беззвучного режима.",
  },
  {
    id: "firmware",
    category: "soft",
    title: "Прошивка",
    priceFrom: 800,
    time: "20–40 мин",
    desc: "Зависает, логотип, сброс, обновление без потери данных — если возможно.",
  },
  {
    id: "unlock",
    category: "soft",
    title: "Разблокировка",
    priceFrom: 800,
    time: "15–40 мин",
    desc: "Графический ключ, Google-аккаунт, забытый пароль — по ситуации.",
  },
  {
    id: "diag",
    category: "soft",
    title: "Диагностика",
    priceFrom: 0,
    time: "15 мин",
    desc: "Смотрим, называем цену до работы. Если не чините — ничего не берём.",
  },
];

export const STEPS = [
  { n: "01", title: "Заявка или звонок", text: "Опишите модель и что случилось — ответим в течение нескольких минут." },
  { n: "02", title: "Диагностика", text: "15 минут на столе. Честная цена до того, как разберём дальше." },
  { n: "03", title: "Ремонт", text: "Большинство экранов и батарей — в тот же день, часто за час." },
  { n: "04", title: "Гарантия", text: "90 дней на работу и запчасть. Чек и рекомендации, как беречь." },
];

export const BRANDS = ["iPhone", "Samsung", "Xiaomi", "Honor", "Huawei", "Realme", "Pixel", "OnePlus"];

export function formatPrice(n: number) {
  if (n === 0) return "Бесплатно";
  return `от ${n.toLocaleString("ru-RU")} ₽`;
}

export function getShopStatus(now = new Date()) {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-GB", {
      timeZone: SHOP.timezone,
      weekday: "short",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    })
      .formatToParts(now)
      .map((p) => [p.type, p.value]),
  );
  const weekday = parts.weekday ?? "";
  const hour = Number(parts.hour);
  const minute = Number(parts.minute);
  const mins = hour * 60 + minute;
  const isSunday = weekday === "Sun";
  const openAt = isSunday ? 11 * 60 : 10 * 60;
  const closeAt = isSunday ? 18 * 60 : 20 * 60;
  const open = mins >= openAt && mins < closeAt;
  return {
    open,
    todayLabel: isSunday ? SHOP.hoursSunday : SHOP.hoursWeek,
    statusLabel: open ? "Открыто" : "Закрыто",
  };
}

export function callHref() {
  return `tel:${SHOP.phoneTel}`;
}

export function whatsappHref(text?: string) {
  const base = `https://wa.me/${SHOP.whatsapp}`;
  if (!text) return base;
  return `${base}?text=${encodeURIComponent(text)}`;
}
