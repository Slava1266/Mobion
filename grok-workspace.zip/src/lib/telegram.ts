export type TelegramUser = {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
};

export type TelegramWebApp = {
  initData: string;
  initDataUnsafe: {
    user?: TelegramUser;
    start_param?: string;
  };
  platform: string;
  ready: () => void;
  expand: () => void;
  close: () => void;
  setHeaderColor: (color: string) => void;
  setBackgroundColor: (color: string) => void;
  disableVerticalSwipes?: () => void;
  openLink: (url: string, options?: { try_instant_view?: boolean }) => void;
  openTelegramLink: (url: string) => void;
  requestContact?: (cb?: (sent: boolean) => void) => void;
  BackButton: {
    show: () => void;
    hide: () => void;
    onClick: (fn: () => void) => void;
    offClick: (fn: () => void) => void;
  };
  HapticFeedback?: {
    impactOccurred: (style: "light" | "medium" | "heavy") => void;
    notificationOccurred: (type: "error" | "success" | "warning") => void;
  };
  onEvent: (event: string, fn: (data?: unknown) => void) => void;
  offEvent: (event: string, fn: (data?: unknown) => void) => void;
};

declare global {
  interface Window {
    Telegram?: { WebApp?: TelegramWebApp };
  }
}

export const START_ROUTES: Record<string, string> = {
  services: "/services",
  uslugi: "/services",
  price: "/services",
  prices: "/services",
  prais: "/services",
  book: "/book",
  zayavka: "/book",
  zapis: "/book",
  repair: "/book",
  contacts: "/contacts",
  contact: "/contacts",
  adres: "/contacts",
  vip: "/vip",
  club: "/vip",
  menu: "/vip",
  rules: "/vip?view=rules",
  pravila: "/vip?view=rules",
  about: "/vip?view=about",
  vozmozhnosti: "/vip?view=about",
  subscribe: "/vip?view=pay",
  podpiska: "/vip?view=pay",
  oplata: "/vip?view=pay",
  pay: "/vip?view=pay",
  status: "/vip?view=status",
  moya: "/vip?view=status",
  chat: "/vip?view=chats",
  chats: "/vip?view=chats",
  flud: "/vip?view=chats",
};

export function getWebApp(): TelegramWebApp | null {
  if (typeof window === "undefined") return null;
  return window.Telegram?.WebApp ?? null;
}

export function isTelegram(): boolean {
  const wa = getWebApp();
  if (!wa) return false;
  return Boolean(wa.initData) || (wa.platform !== "unknown" && wa.platform !== "");
}

export function telegramUser(): TelegramUser | null {
  return getWebApp()?.initDataUnsafe.user ?? null;
}

export function readStartParam(): string {
  if (typeof window === "undefined") return "";
  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get("tgWebAppStartParam") || params.get("startapp") || "";
  const fromTg = getWebApp()?.initDataUnsafe.start_param ?? "";
  return (fromTg || fromQuery).toLowerCase().trim();
}

export function openExternal(url: string) {
  const tg = getWebApp();
  if (tg && isTelegram()) {
    tg.openLink(url);
    return;
  }
  window.open(url, "_blank", "noopener,noreferrer");
}

export function openTelegram(url: string) {
  const tg = getWebApp();
  if (tg && isTelegram() && tg.openTelegramLink) {
    tg.openTelegramLink(url);
    return;
  }
  window.open(url, "_blank", "noopener,noreferrer");
}

export function haptic(kind: "light" | "success" | "error" = "light") {
  const h = getWebApp()?.HapticFeedback;
  if (!h) return;
  if (kind === "success" || kind === "error") h.notificationOccurred(kind);
  else h.impactOccurred("light");
}
