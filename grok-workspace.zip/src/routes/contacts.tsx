import { createFileRoute } from "@tanstack/react-router";
import { Clock3, MapPin, MessageCircle, Navigation, Phone } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { InstallCard } from "@/components/install-card";
import { Button } from "@/components/ui/button";
import { callHref, getShopStatus, SHOP, whatsappHref } from "@/lib/shop";

export const Route = createFileRoute("/contacts")({ component: ContactsPage });

const WEEK = [
  { day: "Понедельник", hours: SHOP.hoursWeek },
  { day: "Вторник", hours: SHOP.hoursWeek },
  { day: "Среда", hours: SHOP.hoursWeek },
  { day: "Четверг", hours: SHOP.hoursWeek },
  { day: "Пятница", hours: SHOP.hoursWeek },
  { day: "Суббота", hours: SHOP.hoursWeek },
  { day: "Воскресенье", hours: SHOP.hoursSunday },
];

function ContactsPage() {
  const status = getShopStatus();
  const weekday = new Intl.DateTimeFormat("ru-RU", {
    timeZone: SHOP.timezone,
    weekday: "long",
  }).format(new Date());

  return (
    <AppShell>
      <div className="px-5 pt-6">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">Сервис</p>
        <h1 className="mt-1 font-display text-2xl font-medium tracking-tight">Контакты</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          {SHOP.city}, {SHOP.address}. Телефон {SHOP.phoneDisplay}. Приходите без записи или оставьте заявку — ответим в рабочие часы.
        </p>

        <div className="mt-6 overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)]">
          <img
            src="/images/tools.jpg"
            alt="Инструменты мастера на рабочем столе"
            className="h-44 w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
          />
          <div className="space-y-4 p-4">
            <div className="flex gap-3">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-accent">
                <MapPin className="size-4" strokeWidth={2} />
              </span>
              <div>
                <p className="text-sm font-medium">{SHOP.addressFull}</p>
                <p className="mt-0.5 text-xs text-muted">Промышленный район</p>
              </div>
            </div>
            <Button asChild className="w-full" size="lg">
              <a href={SHOP.mapsUrl} target="_blank" rel="noreferrer">
                <Navigation className="size-4" strokeWidth={2} />
                Маршрут
              </a>
            </Button>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2.5">
          <Button asChild variant="secondary" size="lg">
            <a href={callHref()}>
              <Phone className="size-4" strokeWidth={2} />
              Позвонить
            </a>
          </Button>
          <Button asChild variant="secondary" size="lg">
            <a href={whatsappHref("Здравствуйте! Пишу из приложения Мобион.")} target="_blank" rel="noreferrer">
              <MessageCircle className="size-4" strokeWidth={2} />
              WhatsApp
            </a>
          </Button>
        </div>

        <section className="mt-6 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Clock3 className="size-4 text-accent" strokeWidth={2} />
              <h2 className="text-sm font-medium">Часы работы</h2>
            </div>
            <span className={status.open ? "text-xs font-medium text-ok" : "text-xs font-medium text-muted"}>
              {status.statusLabel}
            </span>
          </div>
          <ul className="mt-3 space-y-1.5">
            {WEEK.map((row) => {
              const active = row.day.toLowerCase() === weekday;
              return (
                <li
                  key={row.day}
                  className={
                    active
                      ? "flex items-center justify-between text-sm text-fg"
                      : "flex items-center justify-between text-sm text-muted"
                  }
                >
                  <span>{row.day}</span>
                  <span className="tabular-nums">{row.hours}</span>
                </li>
              );
            })}
          </ul>
        </section>

        <div className="mt-6">
          <InstallCard />
        </div>

        <p className="mt-8 pb-4 text-center text-xs leading-relaxed text-subtle">
          {SHOP.name} · {SHOP.addressFull}
          <br />
          {SHOP.phoneDisplay}
        </p>
      </div>
    </AppShell>
  );
}
