import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Clock3, MapPin, Phone, ShieldCheck, ScanSearch } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { InstallCard } from "@/components/install-card";
import { Button } from "@/components/ui/button";
import {
  BRANDS,
  callHref,
  formatPrice,
  getShopStatus,
  SERVICES,
  SHOP,
  STEPS,
} from "@/lib/shop";

export const Route = createFileRoute("/")({ component: Home });

const FEATURED = SERVICES.filter((s) => s.image).slice(0, 4);

function Home() {
  const status = getShopStatus();

  return (
    <AppShell>
      <section className="relative isolate overflow-hidden">
        <img
          src="/images/hero.jpg"
          alt="Мастер ремонтирует смартфон на рабочем столе"
          className="h-96 w-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/10" />
        <div className="absolute inset-x-0 bottom-0 px-5 pb-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <span
              className={
                status.open
                  ? "inline-flex items-center gap-1.5 rounded-full bg-ok/20 px-2.5 py-1 text-xs font-medium text-ok"
                  : "inline-flex items-center gap-1.5 rounded-full bg-bg/70 px-2.5 py-1 text-xs font-medium text-muted"
              }
            >
              <span className={status.open ? "size-1.5 rounded-full bg-ok" : "size-1.5 rounded-full bg-subtle"} />
              {status.statusLabel} · сегодня {status.todayLabel}
            </span>
          </div>
          <h1 className="font-display text-3xl font-medium leading-tight tracking-tight">
            Починим за день.
            <span className="mt-1 block text-muted">Дадим гарантию.</span>
          </h1>
          <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted">
            Сервис ремонта телефонов во Владикавказе. Диагностика бесплатно, цена — до работы.
          </p>
        </div>
      </section>

      <div className="space-y-8 px-5 pt-5">
        <div className="grid grid-cols-2 gap-2.5">
          <Button asChild size="lg">
            <a href={callHref()}>
              <Phone className="size-4" strokeWidth={2} />
              Позвонить
            </a>
          </Button>
          <Button asChild variant="secondary" size="lg">
            <Link to="/book">
              Заявка
              <ArrowRight className="size-4" strokeWidth={2} />
            </Link>
          </Button>
        </div>

        <Link
          to="/vip"
          search={{ view: "menu" }}
          className="flex items-center gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]"
        >
          <span className="flex size-10 items-center justify-center rounded-md bg-surface-2 text-accent">
            <ShieldCheck className="size-4" strokeWidth={2} />
          </span>
          <span className="min-w-0">
            <span className="block text-sm font-medium">VIP-чат мастеров</span>
            <span className="block text-xs text-muted">Правила, подписка и чаты бота @vip_mobion_bot</span>
          </span>
        </Link>

        <a
          href={SHOP.mapsUrl}
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
        >
          <span className="flex size-10 items-center justify-center rounded-md bg-surface-2 text-accent">
            <MapPin className="size-4" strokeWidth={2} />
          </span>
          <span className="min-w-0">
            <span className="block text-sm font-medium">{SHOP.addressFull}</span>
            <span className="block text-xs text-muted">Открыть маршрут в Яндекс Картах</span>
          </span>
        </a>

        <section>
          <div className="mb-3 flex items-end justify-between gap-3">
            <h2 className="font-display text-lg font-medium tracking-tight">Частые ремонты</h2>
            <Link to="/services" className="text-sm text-accent">
              Все услуги
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {FEATURED.map((service) => (
              <Link
                key={service.id}
                to="/book"
                search={{ issue: service.title }}
                className="group overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)]"
              >
                <img
                  src={service.image}
                  alt=""
                  className="h-28 w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
                />
                <div className="p-3">
                  <p className="text-sm font-medium leading-snug">{service.title}</p>
                  <p className="mt-1 text-xs text-muted">{formatPrice(service.priceFrom)}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="grid grid-cols-3 gap-2">
          <Stat icon={ShieldCheck} label="Гарантия" value={SHOP.warranty} />
          <Stat icon={Clock3} label="Большинство" value="за день" />
          <Stat icon={ScanSearch} label="Диагностика" value="0 ₽" />
        </section>

        <section>
          <h2 className="font-display text-lg font-medium tracking-tight">Как это работает</h2>
          <ol className="mt-4 space-y-3">
            {STEPS.map((step) => (
              <li key={step.n} className="flex gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
                <span className="font-display text-sm text-accent">{step.n}</span>
                <span>
                  <span className="block text-sm font-medium">{step.title}</span>
                  <span className="mt-1 block text-sm leading-relaxed text-muted">{step.text}</span>
                </span>
              </li>
            ))}
          </ol>
        </section>

        <section>
          <h2 className="font-display text-lg font-medium tracking-tight">Берём в работу</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {BRANDS.map((brand) => (
              <span
                key={brand}
                className="rounded-full bg-surface px-3 py-1.5 text-xs font-medium text-muted shadow-[var(--shadow-border)]"
              >
                {brand}
              </span>
            ))}
          </div>
        </section>

        <InstallCard />
      </div>
    </AppShell>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof ShieldCheck;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl bg-surface px-3 py-4 text-center shadow-[var(--shadow-border)]">
      <Icon className="mx-auto size-4 text-accent" strokeWidth={2} />
      <p className="mt-2 font-display text-sm font-medium tracking-tight">{value}</p>
      <p className="mt-0.5 text-xs text-muted">{label}</p>
    </div>
  );
}
