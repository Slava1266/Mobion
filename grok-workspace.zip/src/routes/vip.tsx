import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, LockKeyhole, MessageCircle, Send, ShieldCheck } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SHOP, whatsappHref } from "@/lib/shop";
import { haptic, openExternal, openTelegram, telegramUser } from "@/lib/telegram";
import {
  FLUD_URL,
  loadVipRequest,
  saveVipRequest,
  VIP_FEATURES,
  VIP_RULES,
  VIP_VIEWS,
  vipMessage,
  type VipRequest,
  type VipView,
} from "@/lib/vip";

export const Route = createFileRoute("/vip")({
  validateSearch: (search: Record<string, unknown>): { view: VipView } => {
    const raw = typeof search.view === "string" ? search.view : "menu";
    const view = VIP_VIEWS.includes(raw as VipView) ? (raw as VipView) : "menu";
    return { view };
  },
  component: VipPage,
});

const MENU: { view: VipView; title: string; text: string }[] = [
  { view: "rules", title: "Правила", text: "Как ведём себя в чатах мастеров" },
  { view: "about", title: "Возможности", text: "Что даёт VIP-подписка" },
  { view: "pay", title: "Оформить подписку", text: "Заявка на доступ в закрытый чат" },
  { view: "status", title: "Моя подписка", text: "Статус последней заявки" },
  { view: "chats", title: "Чаты", text: "Курилка и вход в VIP" },
];

function VipPage() {
  const { view } = Route.useSearch();
  const navigate = useNavigate();

  function open(next: VipView) {
    haptic("light");
    void navigate({ to: "/vip", search: { view: next } });
  }

  return (
    <AppShell>
      <div className="px-5 pt-6">
        {view === "menu" ? <Menu onOpen={open} /> : null}
        {view === "rules" ? <Rules onBack={() => open("menu")} /> : null}
        {view === "about" ? <About onBack={() => open("menu")} /> : null}
        {view === "pay" ? <Pay onBack={() => open("menu")} onDone={() => open("status")} /> : null}
        {view === "status" ? <Status onBack={() => open("menu")} onPay={() => open("pay")} /> : null}
        {view === "chats" ? <Chats onBack={() => open("menu")} /> : null}
      </div>
    </AppShell>
  );
}

function Back({ onBack, title }: { onBack: () => void; title: string }) {
  return (
    <div className="mb-4 flex items-center gap-2">
      <button
        type="button"
        onClick={onBack}
        className="flex size-11 items-center justify-center rounded-md bg-surface text-fg shadow-[var(--shadow-border)]"
        aria-label="Назад"
      >
        <ArrowLeft className="size-4" strokeWidth={2} />
      </button>
      <h1 className="font-display text-xl font-medium tracking-tight">{title}</h1>
    </div>
  );
}

function Menu({ onOpen }: { onOpen: (view: VipView) => void }) {
  return (
    <>
      <p className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">@vip_mobion_bot</p>
      <h1 className="mt-1 font-display text-2xl font-medium tracking-tight">VIP-чат мастеров</h1>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Обучение ремонту телефонов. Закрытый чат открывается только по платной подписке — все разделы бота здесь, внутри приложения.
      </p>
      <ul className="mt-5 space-y-2.5">
        {MENU.map((item) => (
          <li key={item.view}>
            <button
              type="button"
              onClick={() => onOpen(item.view)}
              className="flex w-full items-center gap-3 rounded-2xl bg-surface p-4 text-left shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
            >
              <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-accent">
                <ShieldCheck className="size-4" strokeWidth={2} />
              </span>
              <span>
                <span className="block text-sm font-medium">{item.title}</span>
                <span className="mt-0.5 block text-xs text-muted">{item.text}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
      <p className="mt-6 text-xs leading-relaxed text-subtle">
        Мастерская для клиентов — в разделах «Услуги» и «Заявка». {SHOP.addressFull}.
      </p>
    </>
  );
}

function Rules({ onBack }: { onBack: () => void }) {
  return (
    <>
      <Back onBack={onBack} title="Правила" />
      <p className="text-sm leading-relaxed text-muted">
        Те же правила, что у чата мастеров Mobion. В VIP дополнительно: вход только после оплаты подписки.
      </p>
      <ol className="mt-4 space-y-2.5">
        {VIP_RULES.map((rule, index) => (
          <li key={rule} className="flex gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <span className="font-display text-sm text-accent">{String(index + 1).padStart(2, "0")}</span>
            <span className="text-sm leading-relaxed">{rule}</span>
          </li>
        ))}
      </ol>
    </>
  );
}

function About({ onBack }: { onBack: () => void }) {
  return (
    <>
      <Back onBack={onBack} title="Возможности" />
      <ul className="space-y-2.5">
        {VIP_FEATURES.map((item) => (
          <li key={item.title} className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <p className="text-sm font-medium">{item.title}</p>
            <p className="mt-1 text-sm leading-relaxed text-muted">{item.text}</p>
          </li>
        ))}
      </ul>
      <Button asChild className="mt-5 w-full" size="lg">
        <Link to="/vip" search={{ view: "pay" }}>
          Оформить подписку
        </Link>
      </Button>
    </>
  );
}

function Pay({ onBack, onDone }: { onBack: () => void; onDone: () => void }) {
  const tgUser = typeof window === "undefined" ? null : telegramUser();
  const [name, setName] = useState(tgUser?.first_name ?? "");
  const [phone, setPhone] = useState("");
  const [username, setUsername] = useState(tgUser?.username ?? "");
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const user = telegramUser();
    if (!user) return;
    setName((v) => v || user.first_name);
    setUsername((v) => v || user.username || "");
  }, []);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (name.trim().length < 2) {
      setError("Напишите имя");
      haptic("error");
      return;
    }
    saveVipRequest({
      name: name.trim(),
      phone: phone.trim(),
      username: username.trim().replace(/^@/, ""),
      comment: comment.trim(),
    });
    haptic("success");
    onDone();
  }

  return (
    <>
      <Back onBack={onBack} title="Подписка" />
      <p className="text-sm leading-relaxed text-muted">
        Заявка остаётся в приложении. Оплату и ссылку на VIP-чат подтверждает бот — сам чат закрытый, ссылку может выдать только он.
      </p>
      <form onSubmit={onSubmit} className="mt-5 space-y-4">
        <label className="block space-y-1.5">
          <Label>Имя</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Как к вам обращаться" required />
        </label>
        <label className="block space-y-1.5">
          <Label>Telegram</Label>
          <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="username" />
        </label>
        <label className="block space-y-1.5">
          <Label>Телефон</Label>
          <Input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" placeholder="8 (999) 000-00-00" />
        </label>
        <label className="block space-y-1.5">
          <Label>Что хотите в обучении</Label>
          <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Платы, экраны, прошивка" />
        </label>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" size="lg" className="w-full">
          <Send className="size-4" strokeWidth={2} />
          Отправить заявку
        </Button>
      </form>
    </>
  );
}

function Status({ onBack, onPay }: { onBack: () => void; onPay: () => void }) {
  const [request, setRequest] = useState<VipRequest | null>(null);
  useEffect(() => {
    setRequest(loadVipRequest());
  }, []);

  return (
    <>
      <Back onBack={onBack} title="Моя подписка" />
      {request ? (
        <div className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="inline-flex items-center gap-2 text-sm font-medium text-accent">
            <LockKeyhole className="size-4" strokeWidth={2} />
            Заявка отправлена, доступ ещё не открыт
          </p>
          <dl className="mt-4 space-y-2 text-sm">
            <Row label="Имя" value={request.name} />
            {request.username ? <Row label="Telegram" value={`@${request.username}`} /> : null}
            {request.phone ? <Row label="Телефон" value={request.phone} /> : null}
            <Row
              label="Когда"
              value={new Date(request.createdAt).toLocaleString("ru-RU", { timeZone: SHOP.timezone })}
            />
          </dl>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Ссылка в VIP-чат придёт в боте после оплаты. Пока её нет — подписка не активна.
          </p>
          <Button className="mt-4 w-full" size="lg" onClick={() => openTelegram(`https://t.me/${SHOP.telegramBot}`)}>
            Открыть бота
          </Button>
          <Button
            className="mt-2.5 w-full"
            variant="secondary"
            size="lg"
            onClick={() => openExternal(whatsappHref(vipMessage(request)))}
          >
            Написать в WhatsApp
          </Button>
        </div>
      ) : (
        <div className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-sm font-medium">Подписки пока нет</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Оформите заявку — бот пришлёт условия оплаты и ссылку на чат.
          </p>
          <Button className="mt-4 w-full" size="lg" onClick={onPay}>
            Оформить подписку
          </Button>
        </div>
      )}
    </>
  );
}

function Chats({ onBack }: { onBack: () => void }) {
  return (
    <>
      <Back onBack={onBack} title="Чаты" />
      <div className="space-y-2.5">
        <article className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-sm font-medium">Курилка мастеров</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">Открытый чат @mobionflud. Неформальное общение, не VIP.</p>
          <Button className="mt-4 w-full" variant="secondary" size="lg" onClick={() => openTelegram(FLUD_URL)}>
            <MessageCircle className="size-4" strokeWidth={2} />
            Открыть курилку
          </Button>
        </article>
        <article className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-sm font-medium">VIP-чат</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Закрыт. Ссылку выдаёт только @vip_mobion_bot после оплаты подписки.
          </p>
          <Button
            className="mt-4 w-full"
            size="lg"
            onClick={() => openTelegram(`https://t.me/${SHOP.telegramBot}?start=chat`)}
          >
            Запросить вход
          </Button>
        </article>
      </div>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="text-muted">{label}</dt>
      <dd className="text-right">{value}</dd>
    </div>
  );
}
