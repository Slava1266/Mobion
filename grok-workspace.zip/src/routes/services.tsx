import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock3 } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import {
  CATEGORIES,
  formatPrice,
  SERVICES,
  type ServiceCategory,
} from "@/lib/shop";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/services")({ component: ServicesPage });

function ServicesPage() {
  const [category, setCategory] = useState<ServiceCategory | "all">("all");
  const list = useMemo(
    () => (category === "all" ? SERVICES : SERVICES.filter((s) => s.category === category)),
    [category],
  );

  return (
    <AppShell>
      <div className="px-5 pt-6">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">Прайс</p>
        <h1 className="mt-1 font-display text-2xl font-medium tracking-tight">Услуги и сроки</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Точная цена — после диагностики. Ниже стартовые суммы, без скрытых доплат в процессе.
        </p>

        <div className="-mx-5 mt-5 flex gap-2 overflow-x-auto px-5 pb-1">
          {CATEGORIES.map((item) => {
            const active = item.id === category;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setCategory(item.id)}
                className={cn(
                  "h-10 shrink-0 rounded-full px-3.5 text-sm font-medium transition-colors duration-150",
                  active ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-[var(--shadow-border)]",
                )}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        <ul className="mt-5 space-y-2.5">
          {list.map((service) => (
            <li key={service.id}>
              <Link
                to="/book"
                search={{ issue: service.title }}
                className="block overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
              >
                {service.image ? (
                  <img
                    src={service.image}
                    alt=""
                    className="h-36 w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
                  />
                ) : null}
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <h2 className="text-sm font-medium">{service.title}</h2>
                    <p className="shrink-0 font-display text-sm text-accent">{formatPrice(service.priceFrom)}</p>
                  </div>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted">{service.desc}</p>
                  <p className="mt-2 inline-flex items-center gap-1.5 text-xs text-subtle">
                    <Clock3 className="size-3.5" strokeWidth={2} />
                    {service.time}
                  </p>
                </div>
              </Link>
            </li>
          ))}
        </ul>

        <div className="mt-6 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-sm font-medium">Не нашли свою поломку?</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Приносите как есть. Скажем, чинится ли и за сколько — до разбора.
          </p>
          <Button asChild className="mt-4 w-full" size="lg">
            <Link to="/book">Оставить заявку</Link>
          </Button>
        </div>
      </div>
    </AppShell>
  );
}
