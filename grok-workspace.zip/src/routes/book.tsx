import { useEffect, useMemo, useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Check, ChevronDown, MessageCircle, Phone } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { bookingMessage, saveBooking, type Booking } from "@/lib/bookings";
import { callHref, DEVICES, ISSUE_OPTIONS, whatsappHref } from "@/lib/shop";
import { cn } from "@/lib/utils";

type BookSearch = { issue?: string };

export const Route = createFileRoute("/book")({
  validateSearch: (search: Record<string, unknown>): BookSearch => ({
    issue: typeof search.issue === "string" ? search.issue : undefined,
  }),
  component: BookPage,
});

const selectClass =
  "h-11 w-full appearance-none rounded-md bg-surface-2 px-3.5 pr-10 text-sm text-fg shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-150 focus-visible:shadow-[0_0_0_1px_var(--color-accent)]";

function BookPage() {
  const { issue: presetIssue } = Route.useSearch();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [device, setDevice] = useState<string>(DEVICES[0]);
  const [issue, setIssue] = useState<string>(ISSUE_OPTIONS[0]);
  const [comment, setComment] = useState("");
  const [saved, setSaved] = useState<Booking | null>(null);

  useEffect(() => {
    if (presetIssue) setIssue(presetIssue);
  }, [presetIssue]);

  const issueList = useMemo(() => {
    if (presetIssue && !ISSUE_OPTIONS.includes(presetIssue as (typeof ISSUE_OPTIONS)[number])) {
      return [presetIssue, ...ISSUE_OPTIONS];
    }
    return [...ISSUE_OPTIONS];
  }, [presetIssue]);

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const trimmedName = name.trim();
    const trimmedPhone = phone.trim();
    if (trimmedName.length < 2) {
      toast.error("Напишите имя");
      return;
    }
    if (trimmedPhone.replace(/\D/g, "").length < 10) {
      toast.error("Проверьте номер телефона");
      return;
    }
    const booking = saveBooking({
      name: trimmedName,
      phone: trimmedPhone,
      device,
      issue,
      comment,
    });
    setSaved(booking);
  }

  if (saved) {
    const message = bookingMessage(saved);
    return (
      <AppShell>
        <div className="px-5 pt-10">
          <div className="flex size-12 items-center justify-center rounded-lg bg-accent text-accent-fg">
            <Check className="size-6" strokeWidth={2} />
          </div>
          <h1 className="mt-5 font-display text-2xl font-medium tracking-tight">Заявка принята</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            {saved.name}, мы свяжемся с вами по номеру {saved.phone}. Можно сразу написать в WhatsApp или позвонить.
          </p>
          <dl className="mt-6 space-y-2 rounded-2xl bg-surface p-4 text-sm shadow-[var(--shadow-border)]">
            <Row label="Устройство" value={saved.device} />
            <Row label="Проблема" value={saved.issue} />
            {saved.comment.trim() ? <Row label="Комментарий" value={saved.comment} /> : null}
          </dl>
          <div className="mt-5 grid gap-2.5">
            <Button asChild size="lg">
              <a href={whatsappHref(message)} target="_blank" rel="noreferrer">
                <MessageCircle className="size-4" strokeWidth={2} />
                Отправить в WhatsApp
              </a>
            </Button>
            <Button asChild variant="secondary" size="lg">
              <a href={callHref()}>
                <Phone className="size-4" strokeWidth={2} />
                Позвонить в сервис
              </a>
            </Button>
            <Button variant="ghost" size="lg" onClick={() => setSaved(null)}>
              Новая заявка
            </Button>
          </div>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="px-5 pt-6">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-subtle">Запись</p>
        <h1 className="mt-1 font-display text-2xl font-medium tracking-tight">Оставить заявку</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Перезвоним, уточним модель и время. Или напишите сразу в WhatsApp — так быстрее.
        </p>

        <form onSubmit={onSubmit} className="mt-6 space-y-4">
          <Field label="Имя">
            <Input
              name="name"
              autoComplete="name"
              placeholder="Как к вам обращаться"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </Field>
          <Field label="Телефон">
            <Input
              name="phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              placeholder="8 (999) 000-00-00"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </Field>
          <Field label="Устройство">
            <SelectWrap>
              <select className={selectClass} value={device} onChange={(e) => setDevice(e.target.value)}>
                {DEVICES.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </SelectWrap>
          </Field>
          <Field label="Что случилось">
            <SelectWrap>
              <select className={selectClass} value={issue} onChange={(e) => setIssue(e.target.value)}>
                {issueList.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </SelectWrap>
          </Field>
          <Field label="Комментарий">
            <Textarea
              name="comment"
              placeholder="Модель, цвет, что уже пробовали"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
          </Field>
          <Button type="submit" size="lg" className="w-full">
            Отправить заявку
          </Button>
        </form>

        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <Button asChild variant="secondary" size="lg">
            <a href={callHref()}>
              <Phone className="size-4" strokeWidth={2} />
              Звонок
            </a>
          </Button>
          <Button
            asChild
            variant="secondary"
            size="lg"
            className={cn(!name.trim() && "opacity-90")}
          >
            <a
              href={whatsappHref(
                bookingMessage({
                  name: name.trim() || "Клиент",
                  phone: phone.trim() || "—",
                  device,
                  issue,
                  comment,
                }),
              )}
              target="_blank"
              rel="noreferrer"
            >
              <MessageCircle className="size-4" strokeWidth={2} />
              WhatsApp
            </a>
          </Button>
        </div>
      </div>
    </AppShell>
  );
}

function SelectWrap({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative">
      {children}
      <ChevronDown
        className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted"
        strokeWidth={2}
      />
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <Label>{label}</Label>
      {children}
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="text-muted">{label}</dt>
      <dd className="text-right">{value}</dd>
    </div>
  );
}
