import { useEffect } from "react";
import { useRouter, useRouterState } from "@tanstack/react-router";
import { callHref } from "@/lib/shop";
import {
  getWebApp,
  isTelegram,
  readStartParam,
  START_ROUTES,
} from "@/lib/telegram";

export function TelegramBridge() {
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    const tg = getWebApp();
    if (!tg) return;

    tg.ready();
    tg.expand();
    tg.setHeaderColor("#0c0d10");
    tg.setBackgroundColor("#0c0d10");
    tg.disableVerticalSwipes?.();

    const inTg = isTelegram();
    document.documentElement.classList.toggle("in-telegram", inTg);
    if (!inTg) return;

    const start = readStartParam();
    if (start === "call" || start === "zvonok") {
      window.location.href = callHref();
      return;
    }
    const target = START_ROUTES[start];
    if (target && router.state.location.pathname === "/") {
      router.history.push(target);
    }
  }, [router]);

  useEffect(() => {
    const tg = getWebApp();
    if (!tg || !isTelegram()) return;

    const onBack = () => {
      if (window.history.length > 1) router.history.back();
      else void router.navigate({ to: "/" });
    };

    if (pathname === "/") tg.BackButton.hide();
    else {
      tg.BackButton.show();
      tg.BackButton.onClick(onBack);
    }

    return () => {
      tg.BackButton.offClick(onBack);
      tg.BackButton.hide();
    };
  }, [pathname, router]);

  return null;
}
