import { Link, useRouterState } from "@tanstack/react-router";
import { ClipboardPen, House, MapPin, Phone, ShieldCheck, Wrench } from "lucide-react";
import { Toaster } from "sonner";
import { LogoMark } from "@/components/logo-mark";
import { Button } from "@/components/ui/button";
import { callHref, getShopStatus, SHOP } from "@/lib/shop";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Главная", icon: House },
  { to: "/services", label: "Услуги", icon: Wrench },
  { to: "/vip", label: "VIP", icon: ShieldCheck },
  { to: "/book", label: "Заявка", icon: ClipboardPen },
  { to: "/contacts", label: "Связь", icon: MapPin },
] as const;

function Header() {
  const status = getShopStatus();

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-bg/85 pt-[env(safe-area-inset-top)] backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-lg items-center justify-between gap-3 px-4">
        <Link to="/" className="flex min-w-0 items-center gap-2.5">
          <LogoMark />
          <span className="min-w-0">
            <span className="block font-display text-sm font-medium tracking-tight">{SHOP.name}</span>
            <span className="block text-xs text-muted">{SHOP.tagline}</span>
          </span>
        </Link>
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "hidden items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium sm:inline-flex",
              status.open ? "bg-ok/15 text-ok" : "bg-surface text-muted",
            )}
          >
            <span className={cn("size-1.5 rounded-full", status.open ? "bg-ok" : "bg-subtle")} />
            {status.statusLabel}
          </span>
          <Button asChild variant="secondary" size="icon" aria-label="Позвонить">
            <a href={callHref()}>
              <Phone className="size-4" strokeWidth={2} />
            </a>
          </Button>
        </div>
      </div>
    </header>
  );
}

function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-md"
      aria-label="Основное меню"
    >
      <div className="mx-auto grid max-w-lg grid-cols-5 px-1 pt-1">
        {NAV.map((item) => {
          const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex min-h-14 flex-col items-center justify-center gap-0.5 rounded-md text-xs font-medium transition-colors duration-150",
                active ? "text-accent" : "text-muted hover:text-fg",
              )}
            >
              <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
              {item.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Header />
      <main className="mx-auto w-full max-w-lg pb-32">{children}</main>
      <BottomNav />
      <Toaster theme="dark" position="top-center" richColors={false} />
    </div>
  );
}
