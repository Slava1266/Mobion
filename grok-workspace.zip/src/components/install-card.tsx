import { useEffect, useState } from "react";
import { Download, Share } from "lucide-react";
import { Button } from "@/components/ui/button";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export function useInstallState() {
  const [promptEvent, setPromptEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [standalone, setStandalone] = useState(false);
  const [ios, setIos] = useState(false);

  useEffect(() => {
    const nav = window.navigator as Navigator & { standalone?: boolean };
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
    setStandalone(isStandalone);
    setIos(/iphone|ipad|ipod/i.test(window.navigator.userAgent));

    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  async function install() {
    if (!promptEvent) return;
    await promptEvent.prompt();
    await promptEvent.userChoice;
    setPromptEvent(null);
  }

  return { promptEvent, standalone, ios, install };
}

export function InstallCard() {
  const { standalone, ios } = useInstallState();

  if (standalone) return null;

  return (
    <section className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="font-display text-base font-medium tracking-tight">Установить на телефон</p>
      <p className="mt-1 text-sm leading-relaxed text-muted">
        Скачайте файл и откройте его. Android попросит разрешение — приложения нет в Google Play, это нормально.
      </p>
      {ios ? (
        <div className="mt-4 rounded-md bg-surface-2 px-3.5 py-3 text-sm leading-relaxed text-muted">
          <p>
            На iPhone: кнопка «Поделиться»
            <Share className="mx-1 inline size-3.5 align-text-bottom" strokeWidth={2} />
            → «На экран Домой».
          </p>
        </div>
      ) : (
        <Button asChild className="mt-4 w-full" size="lg">
          <a href="/mobion.apk" download="Mobion.apk">
            <Download className="size-4" strokeWidth={2} />
            Скачать приложение
          </a>
        </Button>
      )}
    </section>
  );
}
