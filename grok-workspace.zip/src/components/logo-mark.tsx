import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8 shrink-0", className)}
      aria-hidden="true"
    >
      <rect width="32" height="32" rx="8" className="fill-surface-2" />
      <rect x="9" y="5" width="14" height="22" rx="3.2" className="fill-accent" />
      <rect x="11" y="8" width="10" height="13.5" rx="1.2" className="fill-bg" />
      <rect x="14" y="23.2" width="4" height="1.6" rx="0.8" className="fill-bg" />
    </svg>
  );
}
