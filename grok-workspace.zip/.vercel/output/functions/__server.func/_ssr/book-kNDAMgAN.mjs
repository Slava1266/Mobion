import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Check, g as ChevronDown, l as MessageCircle, s as Phone } from "../_libs/lucide-react.mjs";
import { _ as ISSUE_OPTIONS, g as DEVICES, l as Route$3, w as whatsappHref, x as callHref } from "./router-CFMtFgyd.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Button, r as cn, t as AppShell } from "./app-shell-GxBbEIBa.mjs";
import { n as Label, r as Textarea, t as Input } from "./textarea-Bpc8WDpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book-kNDAMgAN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEY = "mobion.bookings";
function loadBookings() {
	if (typeof window === "undefined") return [];
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed : [];
	} catch {
		return [];
	}
}
function saveBooking(input) {
	const booking = {
		...input,
		id: crypto.randomUUID(),
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	const next = [booking, ...loadBookings()].slice(0, 20);
	localStorage.setItem(KEY, JSON.stringify(next));
	return booking;
}
function bookingMessage(b) {
	const lines = [
		"Здравствуйте! Хочу записаться на ремонт в Мобион.",
		`Имя: ${b.name}`,
		`Телефон: ${b.phone}`,
		`Устройство: ${b.device}`,
		`Проблема: ${b.issue}`
	];
	if (b.comment.trim()) lines.push(`Комментарий: ${b.comment.trim()}`);
	return lines.join("\n");
}
var selectClass = "h-11 w-full appearance-none rounded-md bg-surface-2 px-3.5 pr-10 text-sm text-fg shadow-[var(--shadow-border)] outline-none transition-[box-shadow] duration-150 focus-visible:shadow-[0_0_0_1px_var(--color-accent)]";
function BookPage() {
	const { issue: presetIssue } = Route$3.useSearch();
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [device, setDevice] = (0, import_react.useState)(DEVICES[0]);
	const [issue, setIssue] = (0, import_react.useState)(ISSUE_OPTIONS[0]);
	const [comment, setComment] = (0, import_react.useState)("");
	const [saved, setSaved] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (presetIssue) setIssue(presetIssue);
	}, [presetIssue]);
	const issueList = (0, import_react.useMemo)(() => {
		if (presetIssue && !ISSUE_OPTIONS.includes(presetIssue)) return [presetIssue, ...ISSUE_OPTIONS];
		return [...ISSUE_OPTIONS];
	}, [presetIssue]);
	function onSubmit(event) {
		event.preventDefault();
		const trimmedName = name.trim();
		const trimmedPhone = phone.trim();
		if (trimmedName.length < 2) {
			toast.error("Напишите имя");
			return;
		}
		if (trimmedPhone.replace(/\D/g, "").length < 10) {
			toast.error("Проверьте номер телефона");
			return;
		}
		const booking = saveBooking({
			name: trimmedName,
			phone: trimmedPhone,
			device,
			issue,
			comment
		});
		setSaved(booking);
	}
	if (saved) {
		const message = bookingMessage(saved);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-5 pt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-12 items-center justify-center rounded-lg bg-accent text-accent-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-6",
						strokeWidth: 2
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 font-display text-2xl font-medium tracking-tight",
					children: "Заявка принята"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: [
						saved.name,
						", мы свяжемся с вами по номеру ",
						saved.phone,
						". Можно сразу написать в WhatsApp или позвонить."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-6 space-y-2 rounded-2xl bg-surface p-4 text-sm shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Устройство",
							value: saved.device
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Проблема",
							value: saved.issue
						}),
						saved.comment.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Комментарий",
							value: saved.comment
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappHref(message),
								target: "_blank",
								rel: "noreferrer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
									className: "size-4",
									strokeWidth: 2
								}), "Отправить в WhatsApp"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "secondary",
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: callHref(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
									className: "size-4",
									strokeWidth: 2
								}), "Позвонить в сервис"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "lg",
							onClick: () => setSaved(null),
							children: "Новая заявка"
						})
					]
				})
			]
		}) });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-subtle",
				children: "Запись"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-2xl font-medium tracking-tight",
				children: "Оставить заявку"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Перезвоним, уточним модель и время. Или напишите сразу в WhatsApp — так быстрее."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mt-6 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Имя",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "name",
							autoComplete: "name",
							placeholder: "Как к вам обращаться",
							value: name,
							onChange: (e) => setName(e.target.value),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Телефон",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "phone",
							type: "tel",
							inputMode: "tel",
							autoComplete: "tel",
							placeholder: "8 (999) 000-00-00",
							value: phone,
							onChange: (e) => setPhone(e.target.value),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Устройство",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: selectClass,
							value: device,
							onChange: (e) => setDevice(e.target.value),
							children: DEVICES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Что случилось",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: selectClass,
							value: issue,
							onChange: (e) => setIssue(e.target.value),
							children: issueList.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item
							}, item))
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Комментарий",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							name: "comment",
							placeholder: "Модель, цвет, что уже пробовали",
							value: comment,
							onChange: (e) => setComment(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						className: "w-full",
						children: "Отправить заявку"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "secondary",
					size: "lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: callHref(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
							className: "size-4",
							strokeWidth: 2
						}), "Звонок"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "secondary",
					size: "lg",
					className: cn(!name.trim() && "opacity-90"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: whatsappHref(bookingMessage({
							name: name.trim() || "Клиент",
							phone: phone.trim() || "—",
							device,
							issue,
							comment
						})),
						target: "_blank",
						rel: "noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
							className: "size-4",
							strokeWidth: 2
						}), "WhatsApp"]
					})
				})]
			})
		]
	}) });
}
function SelectWrap({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
			className: "pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted",
			strokeWidth: 2
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-right",
			children: value
		})]
	});
}
//#endregion
export { BookPage as component };
