import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as cn } from "./app-shell-GxBbEIBa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/textarea-Bpc8WDpX.js
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-surface-2 px-3.5 text-sm text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle transition-[box-shadow] duration-150", "focus-visible:shadow-[0_0_0_1px_var(--color-accent)]", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-sm font-medium text-fg", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-24 w-full resize-y rounded-md bg-surface-2 px-3.5 py-3 text-sm text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle transition-[box-shadow] duration-150", "focus-visible:shadow-[0_0_0_1px_var(--color-accent)]", className),
		...props
	});
}
//#endregion
export { Label as n, Textarea as r, Input as t };
