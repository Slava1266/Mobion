import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as Clock3 } from "../_libs/lucide-react.mjs";
import { S as formatPrice, h as CATEGORIES, v as SERVICES } from "./router-CFMtFgyd.mjs";
import { n as Button, r as cn, t as AppShell } from "./app-shell-GxBbEIBa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-D5AHrs18.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ServicesPage() {
	const [category, setCategory] = (0, import_react.useState)("all");
	const list = (0, import_react.useMemo)(() => category === "all" ? SERVICES : SERVICES.filter((s) => s.category === category), [category]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-subtle",
				children: "Прайс"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-2xl font-medium tracking-tight",
				children: "Услуги и сроки"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Точная цена — после диагностики. Ниже стартовые суммы, без скрытых доплат в процессе."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-5 mt-5 flex gap-2 overflow-x-auto px-5 pb-1",
				children: CATEGORIES.map((item) => {
					const active = item.id === category;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCategory(item.id),
						className: cn("h-10 shrink-0 rounded-full px-3.5 text-sm font-medium transition-colors duration-150", active ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-[var(--shadow-border)]"),
						children: item.label
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-5 space-y-2.5",
				children: list.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/book",
					search: { issue: service.title },
					className: "block overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
					children: [service.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: service.image,
						alt: "",
						className: "h-36 w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium",
									children: service.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "shrink-0 font-display text-sm text-accent",
									children: formatPrice(service.priceFrom)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 text-sm leading-relaxed text-muted",
								children: service.desc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 inline-flex items-center gap-1.5 text-xs text-subtle",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, {
									className: "size-3.5",
									strokeWidth: 2
								}), service.time]
							})
						]
					})]
				}) }, service.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Не нашли свою поломку?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-muted",
						children: "Приносите как есть. Скажем, чинится ли и за сколько — до разбора."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "mt-4 w-full",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book",
							children: "Оставить заявку"
						})
					})
				]
			})
		]
	}) });
}
//#endregion
export { ServicesPage as component };
