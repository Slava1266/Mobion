import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useNavigate, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Send, d as LockKeyhole, l as MessageCircle, r as ShieldCheck, y as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as VIP_RULES, c as vipMessage, d as openExternal, f as openTelegram, i as VIP_FEATURES, n as Route, o as loadVipRequest, p as telegramUser, r as FLUD_URL, s as saveVipRequest, u as haptic, w as whatsappHref, y as SHOP } from "./router-CFMtFgyd.mjs";
import { n as Button, t as AppShell } from "./app-shell-GxBbEIBa.mjs";
import { n as Label, r as Textarea, t as Input } from "./textarea-Bpc8WDpX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vip-Bi-uw83C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MENU = [
	{
		view: "rules",
		title: "Правила",
		text: "Как ведём себя в чатах мастеров"
	},
	{
		view: "about",
		title: "Возможности",
		text: "Что даёт VIP-подписка"
	},
	{
		view: "pay",
		title: "Оформить подписку",
		text: "Заявка на доступ в закрытый чат"
	},
	{
		view: "status",
		title: "Моя подписка",
		text: "Статус последней заявки"
	},
	{
		view: "chats",
		title: "Чаты",
		text: "Курилка и вход в VIP"
	}
];
function VipPage() {
	const { view } = Route.useSearch();
	const navigate = useNavigate();
	function open(next) {
		haptic("light");
		navigate({
			to: "/vip",
			search: { view: next }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6",
		children: [
			view === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { onOpen: open }) : null,
			view === "rules" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rules, { onBack: () => open("menu") }) : null,
			view === "about" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, { onBack: () => open("menu") }) : null,
			view === "pay" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pay, {
				onBack: () => open("menu"),
				onDone: () => open("status")
			}) : null,
			view === "status" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, {
				onBack: () => open("menu"),
				onPay: () => open("pay")
			}) : null,
			view === "chats" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chats, { onBack: () => open("menu") }) : null
		]
	}) });
}
function Back({ onBack, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onBack,
			className: "flex size-11 items-center justify-center rounded-md bg-surface text-fg shadow-[var(--shadow-border)]",
			"aria-label": "Назад",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
				className: "size-4",
				strokeWidth: 2
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-xl font-medium tracking-tight",
			children: title
		})]
	});
}
function Menu({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium uppercase tracking-[0.14em] text-subtle",
			children: "@vip_mobion_bot"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-1 font-display text-2xl font-medium tracking-tight",
			children: "VIP-чат мастеров"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted",
			children: "Обучение ремонту телефонов. Закрытый чат открывается только по платной подписке — все разделы бота здесь, внутри приложения."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 space-y-2.5",
			children: MENU.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onOpen(item.view),
				className: "flex w-full items-center gap-3 rounded-2xl bg-surface p-4 text-left shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
						className: "size-4",
						strokeWidth: 2
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-medium",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-xs text-muted",
					children: item.text
				})] })]
			}) }, item.view))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-xs leading-relaxed text-subtle",
			children: [
				"Мастерская для клиентов — в разделах «Услуги» и «Заявка». ",
				SHOP.addressFull,
				"."
			]
		})
	] });
}
function Rules({ onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
			onBack,
			title: "Правила"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "Те же правила, что у чата мастеров Mobion. В VIP дополнительно: вход только после оплаты подписки."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-4 space-y-2.5",
			children: VIP_RULES.map((rule, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-sm text-accent",
					children: String(index + 1).padStart(2, "0")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm leading-relaxed",
					children: rule
				})]
			}, rule))
		})
	] });
}
function About({ onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
			onBack,
			title: "Возможности"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2.5",
			children: VIP_FEATURES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: item.text
				})]
			}, item.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-5 w-full",
			size: "lg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/vip",
				search: { view: "pay" },
				children: "Оформить подписку"
			})
		})
	] });
}
function Pay({ onBack, onDone }) {
	const tgUser = typeof window === "undefined" ? null : telegramUser();
	const [name, setName] = (0, import_react.useState)(tgUser?.first_name ?? "");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)(tgUser?.username ?? "");
	const [comment, setComment] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const user = telegramUser();
		if (!user) return;
		setName((v) => v || user.first_name);
		setUsername((v) => v || user.username || "");
	}, []);
	function onSubmit(event) {
		event.preventDefault();
		if (name.trim().length < 2) {
			setError("Напишите имя");
			haptic("error");
			return;
		}
		saveVipRequest({
			name: name.trim(),
			phone: phone.trim(),
			username: username.trim().replace(/^@/, ""),
			comment: comment.trim()
		});
		haptic("success");
		onDone();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
			onBack,
			title: "Подписка"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "Заявка остаётся в приложении. Оплату и ссылку на VIP-чат подтверждает бот — сам чат закрытый, ссылку может выдать только он."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "mt-5 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Имя" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "Как к вам обращаться",
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Telegram" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: username,
						onChange: (e) => setUsername(e.target.value),
						placeholder: "username"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Телефон" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						inputMode: "tel",
						placeholder: "8 (999) 000-00-00"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Что хотите в обучении" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: comment,
						onChange: (e) => setComment(e.target.value),
						placeholder: "Платы, экраны, прошивка"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					size: "lg",
					className: "w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
						className: "size-4",
						strokeWidth: 2
					}), "Отправить заявку"]
				})
			]
		})
	] });
}
function Status({ onBack, onPay }) {
	const [request, setRequest] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setRequest(loadVipRequest());
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
		onBack,
		title: "Моя подписка"
	}), request ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "inline-flex items-center gap-2 text-sm font-medium text-accent",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {
					className: "size-4",
					strokeWidth: 2
				}), "Заявка отправлена, доступ ещё не открыт"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Имя",
						value: request.name
					}),
					request.username ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Telegram",
						value: `@${request.username}`
					}) : null,
					request.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Телефон",
						value: request.phone
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Когда",
						value: new Date(request.createdAt).toLocaleString("ru-RU", { timeZone: SHOP.timezone })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: "Ссылка в VIP-чат придёт в боте после оплаты. Пока её нет — подписка не активна."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full",
				size: "lg",
				onClick: () => openTelegram(`https://t.me/${SHOP.telegramBot}`),
				children: "Открыть бота"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-2.5 w-full",
				variant: "secondary",
				size: "lg",
				onClick: () => openExternal(whatsappHref(vipMessage(request))),
				children: "Написать в WhatsApp"
			})
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Подписки пока нет"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: "Оформите заявку — бот пришлёт условия оплаты и ссылку на чат."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4 w-full",
				size: "lg",
				onClick: onPay,
				children: "Оформить подписку"
			})
		]
	})] });
}
function Chats({ onBack }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Back, {
		onBack,
		title: "Чаты"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Курилка мастеров"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: "Открытый чат @mobionflud. Неформальное общение, не VIP."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "mt-4 w-full",
					variant: "secondary",
					size: "lg",
					onClick: () => openTelegram(FLUD_URL),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
						className: "size-4",
						strokeWidth: 2
					}), "Открыть курилку"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "VIP-чат"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: "Закрыт. Ссылку выдаёт только @vip_mobion_bot после оплаты подписки."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4 w-full",
					size: "lg",
					onClick: () => openTelegram(`https://t.me/${SHOP.telegramBot}?start=chat`),
					children: "Запросить вход"
				})
			]
		})]
	})] });
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-right",
			children: value
		})]
	});
}
//#endregion
export { VipPage as component };
