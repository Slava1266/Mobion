import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Navigation, l as MessageCircle, m as Clock3, s as Phone, u as MapPin } from "../_libs/lucide-react.mjs";
import { C as getShopStatus, w as whatsappHref, x as callHref, y as SHOP } from "./router-CFMtFgyd.mjs";
import { n as Button, t as AppShell } from "./app-shell-GxBbEIBa.mjs";
import { t as InstallCard } from "./install-card-DnCPDdS8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contacts-7YZyd2XT.js
var import_jsx_runtime = require_jsx_runtime();
var WEEK = [
	{
		day: "Понедельник",
		hours: SHOP.hoursWeek
	},
	{
		day: "Вторник",
		hours: SHOP.hoursWeek
	},
	{
		day: "Среда",
		hours: SHOP.hoursWeek
	},
	{
		day: "Четверг",
		hours: SHOP.hoursWeek
	},
	{
		day: "Пятница",
		hours: SHOP.hoursWeek
	},
	{
		day: "Суббота",
		hours: SHOP.hoursWeek
	},
	{
		day: "Воскресенье",
		hours: SHOP.hoursSunday
	}
];
function ContactsPage() {
	const status = getShopStatus();
	const weekday = new Intl.DateTimeFormat("ru-RU", {
		timeZone: SHOP.timezone,
		weekday: "long"
	}).format(/* @__PURE__ */ new Date());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "px-5 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-subtle",
				children: "Сервис"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-2xl font-medium tracking-tight",
				children: "Контакты"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: [
					SHOP.city,
					", ",
					SHOP.address,
					". Телефон ",
					SHOP.phoneDisplay,
					". Приходите без записи или оставьте заявку — ответим в рабочие часы."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/tools.jpg",
					alt: "Инструменты мастера на рабочем столе",
					className: "h-44 w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "size-4",
								strokeWidth: 2
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: SHOP.addressFull
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs text-muted",
							children: "Промышленный район"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "w-full",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: SHOP.mapsUrl,
							target: "_blank",
							rel: "noreferrer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, {
								className: "size-4",
								strokeWidth: 2
							}), "Маршрут"]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "secondary",
					size: "lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: callHref(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
							className: "size-4",
							strokeWidth: 2
						}), "Позвонить"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "secondary",
					size: "lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: whatsappHref("Здравствуйте! Пишу из приложения Мобион."),
						target: "_blank",
						rel: "noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
							className: "size-4",
							strokeWidth: 2
						}), "WhatsApp"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, {
							className: "size-4 text-accent",
							strokeWidth: 2
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Часы работы"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: status.open ? "text-xs font-medium text-ok" : "text-xs font-medium text-muted",
						children: status.statusLabel
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-1.5",
					children: WEEK.map((row) => {
						const active = row.day.toLowerCase() === weekday;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: active ? "flex items-center justify-between text-sm text-fg" : "flex items-center justify-between text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.day }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: row.hours
							})]
						}, row.day);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallCard, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 pb-4 text-center text-xs leading-relaxed text-subtle",
				children: [
					SHOP.name,
					" · ",
					SHOP.addressFull,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					SHOP.phoneDisplay
				]
			})
		]
	}) });
}
//#endregion
export { ContactsPage as component };
